<?php

namespace App\Http\Resources\Product;

use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        dd($this);
        return [
            'id'          => $this->autoId,
            'product_id'    => $this->productId,
            'product_no'    => $this->productNo,
            'name'          => $this->name,
            'description'   => strip_tags( $this->description),
            'price'         => $this->mrp,
            'stock'         => $this->stock == 0 ? 'Out of stock' : $this->stock,
            'discount'      => $this->discount,
            'totalPrice'    => round((1 - ($this->discount/100)) * $this->price, 2),
            'image'         => $this->photo
        ];
    }
}
