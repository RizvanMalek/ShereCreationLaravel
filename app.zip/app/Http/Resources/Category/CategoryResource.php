<?php

namespace App\Http\Resources\Category;

use Illuminate\Http\Resources\Json\ResourceCollection;

class CategoryResource extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'          => $this->autoId,
            'category_id'    => $this->categoryId,
            'category_no'    => $this->categoryNo,
            'name'          => $this->name,
            'image'         => $this->photo
        ];
    }
}
