<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Helpers\AttachmentHelper;

use App\Models\Attachment;
use Validator;

class AttachmentController extends Controller
{
	public function upload(Request $request) {

		$validator = Validator::make($request->all(), [
			'attachment' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048'
		]);

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Error while uploading image.' , 'result' => $validator->errors()]);
		}

		$attachmentFile = $request->file('attachment');
		$attachment = new Attachment;
		$attachment->fileType = $request->input('type');
		$attachment->name = $attachmentFile->getClientOriginalName();
		$attachment->contentType = $attachmentFile->getMimeType();
		$attachment->fileSize = $attachmentFile->getSize();
		$attachment->path = '';
		$attachment->encoding = 'UTF-8';
		$attachment->save();

		$path = AttachmentHelper::upload($attachmentFile->getRealPath() , $request->input('module') , $attachment);

		$attachment->path = $path;
		$attachment->save();

		$attachment->downloadUrl = AttachmentHelper::downloadUrl($attachment->attachmentId);
		$attachment->renderUrl = AttachmentHelper::renderUrl($attachment->attachmentId);

		return response()->json(['status' => true , 'message' => 'File uploaded successfully' , 'result' => $attachment]);
	}

	public function download(Request $request , $attachmentId) {
		$attachment = Attachment::get($attachmentId);
		AttachmentHelper::download($attachment);
	}

	public function render(Request $request , $attachmentId , $size = '' , $trim = '') {
		$attachment = Attachment::get($attachmentId);
		$trim = $trim == 'false' ? false : true;

		if($size) {
			list($width , $height) = explode('x', $size);
			AttachmentHelper::renderThumb($attachment , $width , $height , $trim);
		} else {
			AttachmentHelper::render($attachment);
		}
	}
}
