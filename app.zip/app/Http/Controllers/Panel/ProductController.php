<?php

namespace App\Http\Controllers\Panel;

use Validator;
use App\Models\Tag;
use App\Models\Product;
use App\Models\Category;

use App\Constants\Status;

use App\Models\Subcategory;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Imports\ProductImport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;

class ProductController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:product_view');
         $this->middleware('permission:product_create', ['only' => ['add','save']]);
         $this->middleware('permission:product_update', ['only' => ['edit','save']]);
         $this->middleware('permission:product_delete', ['only' => ['delete']]);
    }

	public function index() {
		return redirect()->route('panel.product.listing');
	}

	public function listing() {
		$categories = Category::stored()->status(Status::$ACTIVE)->orderBy('name')->pluck('name', 'categoryId', 'slug')->all();

		return response()->view('panel.product.listing',['categories' => $categories]);
	}

	public function add() {
		$product = new Product;
		$product->status = Status::$ACTIVE;

		$categories = Category::stored()->status(Status::$ACTIVE)->orderBy('name')->get();
		$subcategories = Subcategory::stored()->categoryId($categories->first()->categoryId)->get();
		$tags = Tag::stored()->status(Status::$ACTIVE)->orderBy('name')->get();

		$tag_group = [];
		$selected_tags = [];
		foreach ($tags as $key => $tag) {
			$tag_group[$tag->group][] = $tag;
		}

		return response()->view('panel.product.add', [
			'product' => $product,
			'categories' => $categories,
			'subcategories' => $subcategories,
			'tag_group'	=> $tag_group,
			'selected_tags' => $selected_tags
		]);
	}

	public function edit($productId) {
		$product = Product::stored()->productId($productId)->first();

		// dump($product->tags->pluck('autoId')->toArray());
		$categories = Category::stored()->get();
		$subcategories = Subcategory::stored()->categoryId($product->categoryId)->get();
		$tags = Tag::stored()->status(Status::$ACTIVE)->orderBy('name')->orderBy('group')->get();

		// dump($tags->pluck('autoId')->toArray());

		$selected_tags = $product->tags->pluck('autoId')->toArray();

		$tag_group = [];
		foreach ($tags as $key => $tag) {
			$tag_group[$tag->group][] = $tag;
		}
		// dd($tag_group);

		if(!$product) {
			return redirect()->route('panel.product.listing')->with(['status' => false, 'message' => 'Product not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.product.add', [
			'product' => $product,
			'categories' => $categories,
			'subcategories' => $subcategories,
			'tag_group'	=> $tag_group,
			'selected_tags' => $selected_tags
		]);
	}

	public function search(Request $request) {
		$productQuery = Product::stored();

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';
		$category = isset($query['category']) ? $query['category'] : '';
		$subcategory = isset($query['subcategory']) ? $query['subcategory'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if (isset($sort)) {
			$productQuery->orderBy($sortBy, $sortDir);
		}

		if (!empty($search)) {
			$productQuery->search($search);
		}

		if (!empty($status)) {
			$productQuery->status($status);
		}

		if (!empty($category)) {
			$productQuery->categoryId($category);
		}

		if (!empty($subcategory)) {
			$productQuery->subcategoryId($subcategory);
		}

		$productsCount = $productQuery->count();
		if ($startIndex != -1) {
			$productQuery->offset($startIndex)->limit($count);
		}

		$products = $productQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($productsCount / $count),
			'perpage' => $count,
			'total' => $productsCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true, 'message' => 'Product retrieved successfully', 'result' => $products, 'meta' => $meta]);
	}

	public function save(Request $request) {
		// dd($request->all());
		$validator = Validator::make($request->all(), [
			'name' => 'required|max:100',
			'slug' => 'required|max:100',
			'categoryId' => 'required|max:50',
			'subcategoryId' => 'required|max:50',
			'SKU' => 'max:20',
			'status' => 'required|int',
			'mrp' => 'required|int'
		]);

		$existingProduct = Product::stored()
				->where('productId', '!=', $request->input('productId'))
				->where('slug', !empty($request->input('slug')) ? $request->input('slug') : Str::slug($request->input('title'), '_'))
				->first();

		if($existingProduct) {
			return response()->json(['status' => false , 'message' => 'Product with same slug already exists.' , 'result' => null]);
		}

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => $validator->errors()]);
		}

		$productId = $request->input('productId');

		if($productId) {
			$product = Product::get($productId);
		} else {
			$product = new Product;
		}

		$product->name = $request->input('name');
		$product->slug = $request->input('slug')?? Str::slug($request->input('title'), '_');
		$product->description = $request->input('description');
		$product->categoryId = $request->input('categoryId');
		$product->subcategoryId = $request->input('subcategoryId');
		$product->photos = $request->input('photos');
		$product->SKU = $request->input('SKU');
		$product->dp = $request->input('dp');
		$product->mrp = $request->input('mrp');
		$product->margin = $request->input('margin');
		$product->is_sale = $request->input('is_sale')?? 0;
		$product->is_new = $request->input('is_new')?? 0;
		$product->is_popular = $request->input('is_popular')?? 0;
		$product->availability = $request->input('availability')?? 0;
		$product->weight = $request->input('weight');
		$product->dimensions = $request->input('dimensions');
		$product->status = $request->input('status');
		$product->save();

		//sync related tags in pivot table
		$product->tags()->sync($request->input('tags'));

		return response()->json(['status' => true , 'message' => 'Product saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$productId = $request->input('productId');
		$product = Product::stored()->productId($productId)->first();

		if($product) {
			$product->delete();
			return response()->json(['status' => true , 'message' => 'Product deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}

	public function upload()
	{
		return response()->view('panel.product.upload');
	}

	public function uploadSave(Request $request)
	{
		Excel::import(new ProductImport, $request->file('file'));

		return back();
	}

	public function featured()
	{
		return response()->view('panel.product.featured');
	}

	public function featuredSave(Request $request)
	{

		dd($request->all());

		return back();
	}
}