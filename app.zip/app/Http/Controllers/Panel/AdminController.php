<?php

namespace App\Http\Controllers\Panel;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Constants\Status;
use App\Constants\UserType;

use App\Models\User;

use Auth;
use Validator;

class AdminController extends Controller
{
	function __construct()
    {
         $this->middleware('permission:admin_view');
         $this->middleware('permission:admin_create', ['only' => ['add','save']]);
         $this->middleware('permission:admin_update', ['only' => ['edit','save']]);
         $this->middleware('permission:admin_delete', ['only' => ['delete']]);
	}

	public function index() {
		return redirect()->route('panel.admin.listing');
	}

	public function listing() {
		return response()->view('panel.admin.listing');
	}

	public function add() {
		$admin = new User;
		$admin->status = Status::$ACTIVE;

		return response()->view('panel.admin.add', ['admin' => $admin]);
	}

	public function edit($adminId) {
		$admin = User::stored()->userId($adminId)->first();

		if(!$admin) {
			return redirect()->route('panel.admin.listing')->with(['status' => false, 'message' => 'Admin not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.admin.add', ['admin' => $admin]);
	}

	public function search(Request $request) {
		$adminQuery = User::stored()->type(UserType::$ADMIN);

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if(isset($sort)) {
			$adminQuery->orderBy($sortBy, $sortDir);
		}

		if(!empty($search)) {
			$adminQuery->search($search);
		}

		if(!empty($status)) {
			$adminQuery->status($status);
		}

		$adminsCount = $adminQuery->count();
		if($startIndex != -1) {
			$adminQuery->offset($startIndex)->limit($count);
		}

		$admins = $adminQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($adminsCount / $count),
			'perpage' => $count,
			'total' => $adminsCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true , 'message' => 'Admin retrieved successfully' , 'result' => $admins , 'meta' => $meta]);
	}

	public function save(Request $request) {
		$validator = Validator::make($request->all(), [
			'firstName' => 'required|max:100',
			'lastName' => 'max:100',
			'email' => 'required|email|max:100',
			'status' => 'required|int',
		]);

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => null]);
		}

		$adminId = $request->input('userId');
		$email = trim($request->input('email'));
		$password = $request->input('password');

		$existingAdmin = User::stored()->where('userId', '!=', $adminId)->email($email)->first();
		if($existingAdmin) {
			return response()->json(['status' => false , 'message' => 'Admin with same email already exists.' , 'result' => null]);
		}

		if($adminId) {
			$admin = User::get($adminId);
		} else {
			$admin = new User;
		}

		if($password) {
			$admin->password = bcrypt($password);
		}

		$admin->firstName = $request->input('firstName');
		$admin->lastName = $request->input('lastName');
		$admin->email = $email;
		$admin->type = UserType::$ADMIN;
		$admin->status = $request->input('status');
		$admin->save();

		return response()->json(['status' => true , 'message' => 'Admin saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$adminId = $request->input('adminId');
		$admin = User::stored()->type(UserType::$ADMIN)->adminId($adminId)->first();

		if($admin && (Auth::user()->adminId != $admin->adminId)) {
			$admin->delete();
			return response()->json(['status' => true , 'message' => 'Admin deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}
}
