<?php

namespace App\Http\Controllers\Panel;

use App\Constants\Status;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Role;
use Auth;

use Validator;

class UserController extends Controller
{

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:user_view');
         $this->middleware('permission:user_create', ['only' => ['add','save']]);
         $this->middleware('permission:user_update', ['only' => ['edit','save']]);
         $this->middleware('permission:user_delete', ['only' => ['delete']]);
    }


    /**
     * function will redirect to the available user listing.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function index()
    {
        return redirect()->route('panel.user.listing');
    }

    /**
     * function will show all the user in listing view.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function listing()
    {

        return view('panel.user.listing');
    }

    /**
     * Add new user to the system.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function add()
    {
        //dd(RolesPermissions::$PERMISSIONS['user']['user_create']);
        // if (! Auth::user()->hasPermissionTo('user_create')) {
        //     abort(403);
        // }


        $user = new User();
        $user->status = Status::$ACTIVE;

        $user_roles = [];

        $roles = Role::stored()->pluck('name');

        return view('panel.user.add', ['user' => $user, 'roles' => $roles, 'user_roles' => $user_roles]);
    }

    /**
     * Update any existing user.
     *
     * @param $userId
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit($userId)
    {
        $user = User::with('roles')->stored()->userId($userId)->first();

        $user_roles = $user->roles->pluck('name')->toArray();

        $roles = Role::stored()->pluck('name');

        return view('panel.user.add', ['user' => $user, 'roles' => $roles, 'user_roles' => $user_roles]);
    }

    /**
     * ajax function, which will handle the search request for user users.
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function search(Request $request)
    {
        $userQuery = User::with('roles')->stored();

        $query = $request->input('query');
        $pagination = $request->input('pagination');

        $search = isset($query['search']) ? $query['search'] : '';
        $status = isset($query['status']) ? $query['status'] : '';

        $page = (int) $pagination['page'];
        $count = (int) $pagination['perpage'];
        $startIndex = ($page - 1) * $count;

        $sort = $request->input('sort');
        $sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
        $sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

        if(isset($sort)) {
            $userQuery->orderBy($sortBy, $sortDir);
        }

        if(!empty($search)) {
            $userQuery->search($search);
        }

        if(!empty($status)) {
            $userQuery->status($status);
        }

        $usersCount = $userQuery->count();
        if($startIndex != -1) {
            $userQuery->offset($startIndex)->limit($count);
        }

        $users = $userQuery->get();

        $meta = [
            'page' => $page,
            'pages' => ceil($usersCount / $count),
            'perpage' => $count,
            'total' => $usersCount,
            'sort' => $sortDir,
            'field' => $sortBy,
            'startIndex' => $startIndex
        ];

        return response()->json(['status' => true , 'message' => 'User retrieved successfully' , 'result' => $users , 'meta' => $meta]);
    }

    /**
     * Save new/update existing user.
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function save(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'firstName' => 'required|max:100',
            'lastName' => 'required|max:100',
            'email' => 'required|email|max:100',
            'status' => 'required|int',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => false, 'message' => 'Please re-check all fields.', 'result' => $validator->errors()]);
        }

        $userId = $request->input('userId');
        $email = trim($request->input('email'));
        $password = $request->input('password');

        $existingUser = User::stored()->where('userId', '!=', $userId)->email($email)->first();

        if($existingUser) {
            return response()->json(['status' => false , 'message' => 'User with same email already exists.' , 'result' => null]);
        }

        if($userId) {
            $user = User::get($userId);
        } else {
            $user = new User;
        }

        if($password) {
            $user->password = bcrypt($password);
        }

        try {
            $user->first_name = $request->input('firstName');
            $user->last_name = $request->input('lastName');
            //$user->photos = $request->input('photos');
            $user->email = $email;
            $user->status = $request->input('status');
            $user->save();

            $roles = $request->input('roles');
            $user->syncRoles($roles);

            return response()->json(['status' => true, 'message' => 'User saved successfully.', 'result' => $user->userId]);
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => 'Server error, please retry', 'result' => $e->getMessage()]);
        }
    }

    /**
     * Delete the user.
     *
     * @param $userId
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete($userId)
    {
        $user = User::userId($userId)->first();
        $user->delete();

        return response()->json(['status' => true, 'message' => 'user has been deleted.', 'result' => $user->userId]);
    }
}
