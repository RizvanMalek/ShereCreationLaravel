<?php

namespace App\Http\Controllers\Panel;

use Auth;
use Validator;

use App\Models\Gallery;

use App\Constants\Status;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class GalleryController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:gallery_view');
         $this->middleware('permission:gallery_create', ['only' => ['add','save']]);
         $this->middleware('permission:gallery_update', ['only' => ['edit','save']]);
         $this->middleware('permission:gallery_delete', ['only' => ['delete']]);
    }

	public function index() {
		return redirect()->route('panel.gallery.listing');
	}

	public function listing() {
		return response()->view('panel.gallery.listing');
	}

	public function add() {
		$gallery = new Gallery;
		$gallery->status = Status::$ACTIVE;

		return response()->view('panel.gallery.add', ['gallery' => $gallery]);
	}

	public function edit($galleryId) {
		$gallery = Gallery::stored()->galleryId($galleryId)->first();

		if(!$gallery) {
			return redirect()->route('panel.gallery.listing')->with(['status' => false, 'message' => 'Gallery not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.gallery.add', ['gallery' => $gallery]);
	}

	public function search(Request $request) {
		$galleryQuery = Gallery::stored();

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';
		$type = isset($query['type']) ? $query['type'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if(isset($sort)) {
			$galleryQuery->orderBy($sortBy, $sortDir);
		}

		if(!empty($search)) {
			$galleryQuery->search($search);
		}

		if(!empty($status)) {
			$galleryQuery->status($status);
		}

		if(!empty($type)) {
			$galleryQuery->where('type', $type);
		}

		$gallerysCount = $galleryQuery->count();
		if($startIndex != -1) {
			$galleryQuery->offset($startIndex)->limit($count);
		}

		$gallerys = $galleryQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($gallerysCount / $count),
			'perpage' => $count,
			'total' => $gallerysCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true , 'message' => 'Gallery retrieved successfully' , 'result' => $gallerys , 'meta' => $meta]);
	}

	public function save(Request $request) {
		$validator = Validator::make($request->all(), [
			'type' => 'required',
			'title' => 'required|max:100',
			'date' => 'required',
			'status' => 'required|int',
		]);

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => $validator->errors()]);
		}

		$galleryId = $request->input('galleryId');

		if($galleryId) {
			$gallery = Gallery::get($galleryId);
		} else {
			$gallery = new Gallery;
		}

		$gallery->type = $request->input('type');
		$gallery->date = $request->input('date');
		$gallery->title = $request->input('title');
		$gallery->slug = $request->input('slug');
		$gallery->photos = $request->input('photos');
		$gallery->status = $request->input('status');
		$gallery->save();

		return response()->json(['status' => true , 'message' => 'Gallery saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$galleryId = $request->input('galleryId');
		$gallery = Gallery::stored()->galleryId($galleryId)->first();

		if($gallery) {
			$gallery->delete();
			return response()->json(['status' => true , 'message' => 'Gallery deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}
}
