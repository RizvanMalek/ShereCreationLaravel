<?php

namespace App\Http\Controllers\Panel;

use Auth;
use Validator;

use App\Models\Page;

use App\Constants\Status;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PageController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:page_view');
         $this->middleware('permission:page_create', ['only' => ['add','save']]);
         $this->middleware('permission:page_update', ['only' => ['edit','save']]);
         $this->middleware('permission:page_delete', ['only' => ['delete']]);
    }

	public function index() {
		return redirect()->route('panel.page.listing');
	}

	public function listing() {
		return response()->view('panel.page.listing');
	}

	public function add() {
		$page = new Page;
		$page->status = Status::$ACTIVE;

		return response()->view('panel.page.add', ['page' => $page]);
	}

	public function edit($pageId) {
		$page = Page::stored()->pageId($pageId)->first();

		if(!$page) {
			return redirect()->route('panel.page.listing')->with(['status' => false, 'message' => 'Page not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.page.add', ['page' => $page]);
	}

	public function search(Request $request) {
		$pageQuery = Page::stored();

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if(isset($sort)) {
			$pageQuery->orderBy($sortBy, $sortDir);
		}

		if(!empty($search)) {
			$pageQuery->search($search);
		}

		if(!empty($status)) {
			$pageQuery->status($status);
		}

		$facultiesCount = $pageQuery->count();
		if($startIndex != -1) {
			$pageQuery->offset($startIndex)->limit($count);
		}

		$faculties = $pageQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($facultiesCount / $count),
			'perpage' => $count,
			'total' => $facultiesCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true , 'message' => 'Page retrieved successfully' , 'result' => $faculties , 'meta' => $meta]);
	}

	public function save(Request $request) {
		$validator = Validator::make($request->all(), [
			'title' => 'required|max:100',
			'description' => 'required',
			'status' => 'required|int',
		]);

		$existingPage = Page::stored()
				->where('pageId', '!=', $request->input('pageId'))
				->where('slug', !empty($request->input('slug')) ? $request->input('slug') : Str::slug($request->input('title'), '_'))
				->first();

		if($existingPage) {
			return response()->json(['status' => false , 'message' => 'Page with same slug already exists.' , 'result' => null]);
		}

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => null]);
		}

		$pageId = $request->input('pageId');

		if($pageId) {
			$page = Page::get($pageId);
		} else {
			$page = new Page;
		}

		$page->title = $request->input('title');
		$page->slug = !empty($request->input('slug')) ? $request->input('slug') : Str::slug($request->input('title'), '_');
		$page->photoId = $request->input('photoId');
		$page->description = $request->input('description');
		$page->subtitle = $request->input('subtitle');
		$page->status = $request->input('status');
		$page->save();

		return response()->json(['status' => true , 'message' => 'Page saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$pageId = $request->input('pageId');
		$page = Page::stored()->pageId($pageId)->first();

		if($page) {
			$page->delete();
			return response()->json(['status' => true , 'message' => 'Page deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}
}