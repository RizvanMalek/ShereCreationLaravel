<?php

namespace App\Http\Controllers\Panel;

use Validator;
use App\Models\Category;
use App\Models\Subcategory;

use App\Constants\Status;

use Illuminate\Support\Str;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SubcategoryController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:subcategory_view');
         $this->middleware('permission:subcategory_create', ['only' => ['add','save']]);
         $this->middleware('permission:subcategory_update', ['only' => ['edit','save']]);
         $this->middleware('permission:subcategory_delete', ['only' => ['delete']]);
    }

	public function index() {
		return redirect()->route('panel.subcategory.listing');
	}

	public function listing() {
		return response()->view('panel.subcategory.listing');
	}

	public function add() {
		$subcategory = new Subcategory;
		$subcategory->status = Status::$ACTIVE;

		$categories = Category::stored()->get();

		return response()->view('panel.subcategory.add', ['subcategory' => $subcategory, 'categories' => $categories]);
	}

	public function edit($subcategoryId) {
		$subcategory = Subcategory::stored()->subcategoryId($subcategoryId)->first();

		$categories = Category::stored()->get();

		if(!$subcategory) {
			return redirect()->route('panel.subcategory.listing')->with(['status' => false, 'message' => 'Subcategory not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.subcategory.add', ['subcategory' => $subcategory, 'categories' => $categories]);
	}

	public function search(Request $request) {
		$subcategoryQuery = Subcategory::stored();

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if (isset($sort)) {
			$subcategoryQuery->orderBy($sortBy, $sortDir);
		}

		if (!empty($search)) {
			$subcategoryQuery->search($search);
		}

		if (!empty($status)) {
			$subcategoryQuery->status($status);
		}

		$subcategoriesCount = $subcategoryQuery->count();
		if ($startIndex != -1) {
			$subcategoryQuery->offset($startIndex)->limit($count);
		}

		$subcategories = $subcategoryQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($subcategoriesCount / $count),
			'perpage' => $count,
			'total' => $subcategoriesCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true, 'message' => 'Subcategory retrieved successfully', 'result' => $subcategories, 'meta' => $meta]);
	}

	public function save(Request $request) {
		$validator = Validator::make($request->all(), [
			'name' => 'required|max:100',
			'slug' => 'required|max:100',
			'categoryId' => 'required|max:50',
			'description' => 'max:100',
			'status' => 'required|int',
		]);

		$existingSubcategory = Subcategory::stored()
				->where('subcategoryId', '!=', $request->input('subcategoryId'))
				->where('slug', !empty($request->input('slug')) ? $request->input('slug') : Str::slug($request->input('title'), '_'))
				->first();

		if($existingSubcategory) {
			return response()->json(['status' => false , 'message' => 'Subcategory with same slug already exists.' , 'result' => null]);
		}

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => $validator->errors()]);
		}

		$subcategoryId = $request->input('subcategoryId');

		if($subcategoryId) {
			$subcategory = Subcategory::get($subcategoryId);
		} else {
			$subcategory = new Subcategory;
		}

		$subcategory->name = $request->input('name');
		$subcategory->slug = $request->input('slug')?? Str::slug($request->input('title'), '_');
		$subcategory->categoryId = $request->input('categoryId');
		$subcategory->photoId = $request->input('photoId');
		$subcategory->description = $request->input('description');
		$subcategory->status = $request->input('status');
		$subcategory->save();

		return response()->json(['status' => true , 'message' => 'Subcategory saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$subcategoryId = $request->input('subcategoryId');
		$subcategory = Subcategory::stored()->subcategoryId($subcategoryId)->first();

		if($subcategory) {
			$subcategory->delete();
			return response()->json(['status' => true , 'message' => 'Subcategory deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}

	public function categories(Request $request)
	{
		$categoryId = $request->input('categoryId');
		$subcategories = Subcategory::stored()->categoryId($categoryId)->get();

		if($subcategories)
			return response()->json(['status' => true, 'message' => 'Categories retrieved successfully', 'result' => $subcategories]);

		return response()->json(['status' => false, 'message' => 'Failed to retrieved Categories.', 'result' => null]);
	}
}