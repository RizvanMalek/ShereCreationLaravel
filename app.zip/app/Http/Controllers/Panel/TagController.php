<?php

namespace App\Http\Controllers\Panel;

use Validator;
use App\Models\Tag;

use App\Models\Product;

use App\Constants\Status;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TagController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:tag_view');
         $this->middleware('permission:tag_create', ['only' => ['add','save']]);
         $this->middleware('permission:tag_update', ['only' => ['edit','save']]);
         $this->middleware('permission:tag_delete', ['only' => ['delete']]);
    }

	public function index() {
		return redirect()->route('panel.tag.listing');
	}

	public function listing() {
		return response()->view('panel.tag.listing');
	}

	public function add() {
		$tag = new Tag;
		$tag->status = Status::$ACTIVE;

		$products = Product::stored()->with('Category')->get();
		$product_group = [];
		$selected_products = [];
		foreach ($products as $key => $product) {
			$product_group[$product->Category->name][] = $product;
		}

		return response()->view('panel.tag.add', [
			'tag' => $tag,
			'product_group' => $product_group,
			'selected_products' => $selected_products
			]);
	}

	public function edit($tagId) {
		$tag = Tag::stored()->tagId($tagId)->first();

		$products = Product::stored()->with('Category')->get();
		$product_group = [];
		foreach ($products as $key => $product) {
			$product_group[$product->Category->name][] = $product;
		}
		$selected_products = $tag->products()->pluck('autoId')->toArray();

		// dd($selected_products);

		if(!$tag) {
			return redirect()->route('panel.tag.listing')->with(['status' => false, 'message' => 'Tag not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.tag.add', [
			'tag' => $tag,
			'product_group' => $product_group,
			'selected_products' => $selected_products
		]);
	}

	public function search(Request $request) {
		$tagQuery = Tag::stored();

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if (isset($sort)) {
			$tagQuery->orderBy($sortBy, $sortDir);
		}

		if (!empty($search)) {
			$tagQuery->search($search);
		}

		if (!empty($status)) {
			$tagQuery->status($status);
		}

		$categoriesCount = $tagQuery->count();
		if ($startIndex != -1) {
			$tagQuery->offset($startIndex)->limit($count);
		}

		$categories = $tagQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($categoriesCount / $count),
			'perpage' => $count,
			'total' => $categoriesCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true, 'message' => 'Tag retrieved successfully', 'result' => $categories, 'meta' => $meta]);
	}

	public function save(Request $request) {
		$validator = Validator::make($request->all(), [
			'name' => 'required|max:100',
			'group' => 'required|max:50',
			'status' => 'required|int',
		]);

		$slug = Str::slug($request->input('name'), '-');

		$existingTag = Tag::stored()
				->where('tagId', '!=', $request->input('tagId'))
				->where('slug', $slug)
				->first();

		if($existingTag) {
			return response()->json(['status' => false , 'message' => 'Tag with same slug already exists.' , 'result' => null]);
		}

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => $validator->errors()]);
		}

		$tagId = $request->input('tagId');

		if($tagId) {
			$tag = Tag::get($tagId);
		} else {
			$tag = new Tag;
		}

		$tag->name = $request->input('name');
		$tag->slug = $slug;
		$tag->group = $request->input('group');
		$tag->photoId = $request->input('photoId');
		$tag->status = $request->input('status');
		$tag->save();

		//sync related products in pivot table
		$tag->products()->sync($request->input('products'));

		return response()->json(['status' => true , 'message' => 'Tag saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$tagId = $request->input('tagId');
		$tag = Tag::stored()->tagId($tagId)->first();

		if($tag) {
			$tag->delete();
			return response()->json(['status' => true , 'message' => 'Tag deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}
}