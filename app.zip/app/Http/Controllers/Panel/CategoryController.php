<?php

namespace App\Http\Controllers\Panel;

use Validator;
use App\Models\Category;

use App\Constants\Status;

use Illuminate\Support\Str;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:category_view');
         $this->middleware('permission:category_create', ['only' => ['add','save']]);
         $this->middleware('permission:category_update', ['only' => ['edit','save']]);
         $this->middleware('permission:category_delete', ['only' => ['delete']]);
    }

	public function index() {
		return redirect()->route('panel.category.listing');
	}

	public function listing() {
		return response()->view('panel.category.listing');
	}

	public function add() {
		$category = new Category;
		$category->status = Status::$ACTIVE;

		return response()->view('panel.category.add', ['category' => $category]);
	}

	public function edit($categoryId) {
		$category = Category::stored()->categoryId($categoryId)->first();

		if(!$category) {
			return redirect()->route('panel.category.listing')->with(['status' => false, 'message' => 'Category not found.', 'type' => 'danger', 'result' => null]);
		}

		return response()->view('panel.category.add', ['category' => $category]);
	}

	public function search(Request $request) {
		$categoryQuery = Category::stored();

		$query = $request->input('query');
		$pagination = $request->input('pagination');

		$search = isset($query['search']) ? $query['search'] : '';
		$status = isset($query['status']) ? $query['status'] : '';

		$page = (int) $pagination['page'];
		$count = (int) $pagination['perpage'];
		$startIndex = ($page - 1) * $count;

		$sort = $request->input('sort');
		$sortBy = isset($sort['field']) ? $sort['field'] : 'autoId';
		$sortDir = isset($sort['sort']) ? $sort['sort'] : 'desc';

		if (isset($sort)) {
			$categoryQuery->orderBy($sortBy, $sortDir);
		}

		if (!empty($search)) {
			$categoryQuery->search($search);
		}

		if (!empty($status)) {
			$categoryQuery->status($status);
		}

		$categoriesCount = $categoryQuery->count();
		if ($startIndex != -1) {
			$categoryQuery->offset($startIndex)->limit($count);
		}

		$categories = $categoryQuery->get();

		$meta = [
			'page' => $page,
			'pages' => ceil($categoriesCount / $count),
			'perpage' => $count,
			'total' => $categoriesCount,
			'sort' => $sortDir,
			'field' => $sortBy,
			'startIndex' => $startIndex
		];

		return response()->json(['status' => true, 'message' => 'Category retrieved successfully', 'result' => $categories, 'meta' => $meta]);
	}

	public function save(Request $request) {
		$validator = Validator::make($request->all(), [
			'name' => 'required|max:100',
			'slug' => 'required|max:100',
			'description' => 'max:100',
			'status' => 'required|int',
		]);

		$existingCategory = Category::stored()
				->where('categoryId', '!=', $request->input('categoryId'))
				->where('slug', !empty($request->input('slug')) ? $request->input('slug') : Str::slug($request->input('title'), '_'))
				->first();

		if($existingCategory) {
			return response()->json(['status' => false , 'message' => 'Category with same slug already exists.' , 'result' => null]);
		}

		if($validator->fails()) {
			return response()->json(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => $validator->errors()]);
		}

		$categoryId = $request->input('categoryId');

		if($categoryId) {
			$category = Category::get($categoryId);
		} else {
			$category = new Category;
		}

		$category->name = $request->input('name');
		$category->slug = $request->input('slug')?? Str::slug($request->input('title'), '_');
		$category->photoId = $request->input('photoId');
		$category->description = $request->input('description');
		$category->status = $request->input('status');
		$category->save();

		return response()->json(['status' => true , 'message' => 'Category saved successfully.' , 'result' => null]);
	}

	public function delete(Request $request) {
		$categoryId = $request->input('categoryId');
		$category = Category::stored()->categoryId($categoryId)->first();

		if($category) {
			$category->delete();
			return response()->json(['status' => true , 'message' => 'Category deleted successfully.' , 'result' => null]);
		}

		return response()->json(['status' => false , 'message' => 'Please try again later.' , 'result' => null]);
	}
}