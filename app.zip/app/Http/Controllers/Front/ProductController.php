<?php

namespace App\Http\Controllers\Front;

use App\Models\Tag;
use App\Models\Product;

use App\Models\Setting;

use App\Models\Category;
use App\Constants\Status;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProductController extends Controller
{
	public function index() {

		$products = Product::stored()
			->whereHas('Category', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->whereHas('Subcategory', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->status(Status::$ACTIVE)
			->orderBy('views', 'DESC')
			->paginate();

		// dd($products);

		$settings = Setting::get_settings();

		return response()->view('front.products.index', [
			'settings'		=> $settings,
			'products'		=> $products,
			'page_title'	=> 'All Products'
		]);
	}

	public function details(Request $request, $slug)
	{
		$product = Product::stored()
			->whereHas('Category', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->whereHas('Subcategory', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->status(Status::$ACTIVE)
			->slug($slug)
			->firstOrFail();

		if($product){
			//update product view
			$product->views = $product->views + 1;
			$product->save();
			//save in session for recent viewed
			$request->session()->push('products.recent_view', $product->autoId);
		}

		$settings = Setting::get_settings();

		return response()->view('front.products.details', [
			'product'		=> $product,
			'settings'		=> $settings,
		]);
	}

	public function categoryProducts(Request $request, $slug)
	{
		$category = Category::stored()->where('slug', $slug)->firstOrFail();

		$products = Product::stored()
			->whereHas('Category', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->whereHas('Subcategory', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->where('categoryId', $category->categoryId)
			->status(Status::$ACTIVE)
			->orderBy('views', 'DESC')->paginate();

		return response()->view('front.products.index', [
			'products'		=> $products,
			'page_title'	=> $category->name
		]);
	}

	public function subcategoryProducts(Request $request, $slug)
	{
		$subcategory = Subcategory::stored()->where('slug', $slug)->firstOrFail();

		$products = Product::stored()
			->whereHas('Category', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->whereHas('Subcategory', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->where('subcategoryId', $subcategory->subcategoryId)
			->status(Status::$ACTIVE)->orderBy('views', 'DESC')->paginate();

		return response()->view('front.products.index', [
			'products'		=> $products,
			'page_title'	=> $subcategory->name
		]);
	}

	public function tagProducts(Request $request, $slug)
	{
		$tag = Tag::stored()->where('slug', $slug)->firstOrFail();

		// dd($tag);

		$products = $tag->products()
			->whereHas('Category', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->whereHas('Subcategory', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->status(Status::$ACTIVE)->orderBy('views', 'DESC')->paginate();

		return response()->view('front.products.index', [
			'products'		=> $products,
			'page_title'	=> $tag->name
		]);
	}


}
