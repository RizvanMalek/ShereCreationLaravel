<?php

namespace App\Http\Controllers\Front;

use Mail;
use Validator;
use Carbon\Carbon;

use App\Models\Tag;
use App\Models\Page;

use App\Rules\Captcha;
use App\Models\Gallery;
use App\Models\Product;
use App\Models\Setting;
use App\Constants\Status;
use Illuminate\Http\Request;
use App\Constants\CommonConstants;
use App\Http\Controllers\Controller;

class PageController extends Controller
{
	public function index() {

		$products = Product::stored()
			->whereHas('Category', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->whereHas('Subcategory', function($q){
				$q->where('status', Status::$ACTIVE);
			})
			->status(Status::$ACTIVE)
			->orderBy('views', 'DESC')
			->paginate();

		$settings = Setting::get_settings();

		$featured_tags = ['birthday-gifts', 'anniversary-gifts', 'for-him', 'for-her'];
		$tags = Tag::stored()->where('status', Status::$ACTIVE)->whereIn('slug', $featured_tags)->limit(4)->get();

		return response()->view('front.page.index', [
			'settings'		=> $settings,
			'products'		=> $products,
			'tags'			=> $tags
		]);
	}

	public function page(Request $request, $slug) {
		$page = Page::stored()->where('slug', $slug)->status(Status::$ACTIVE)->first();
		if (!$page) {
			return redirect()->route('front.page.index');
		}
		return response()->view('front.page.page.view', ['page' => $page]);
	}

	public function contact(Request $request)
	{
		$settings = Setting::get_settings();
		return response()->view('front.page.contact',['settings' => $settings]);
	}
}
