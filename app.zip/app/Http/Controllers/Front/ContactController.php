<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Mail;
use Validator;

use App\Models\Contact;
use App\Models\Setting;
use App\Rules\Captcha;

use App\Constants\Status;
use App\Constants\CommonConstants;

class ContactController extends Controller
{
	public function index() {

		$settings = Setting::get_settings();
		return response()->view('front.contact.index',['settings' => $settings]);
	}

	public function save(Request $request)
	{
		$validator = Validator::make($request->all(), [
			'firstName' => 'required|max:100',
			'lastName' => 'max:100',
			'email' => 'required|email|max:100',
			'recaptcha' => new Captcha(),
		]);

		if($validator->fails()) {
			return redirect()->route('front.contact.index')->with(['status' => false , 'message' => 'Please re-check all fields.' , 'result' => $validator->errors()]);
		}

		$email = trim($request->input('email'));
		$contact = new Contact;

		$contact->firstName = $request->input('firstName');
		$contact->lastName = $request->input('lastName');
		$contact->email = $email;
		$contact->mobile = $request->input('mobile');
		$contact->message = $request->input('message');
		$contact->save();

		$data = [
			'receiverEmail' => env('CONTACT_EMAIL'),
			'emailSubject' => env('APP_NAME') . ' - '. 'New Contact Request',
			'firstName' => $contact->firstName,
			'lastName' => $contact->lastName,
			'mobile' => $contact->mobile,
			'userEmail' => $contact->email,
			'userMessage' => $contact->message,
		];

		Mail::send('emails.front.contact.user', $data, function ($m) use ($data){
			$m->from(env('CONTACT_EMAIL'), env('CONTACT_EMAIL_NAME'));
			$m->bcc(env('CONTACT_EMAIL'), env('CONTACT_EMAIL_NAME'));
			$m->to(env('CONTACT_EMAIL'), env('CONTACT_EMAIL_NAME'));

			$m->subject($data['emailSubject']);
		});

		return redirect()->route('front.contact.index')->with(['status' => true , 'message' => 'We have received your request, Our representative will contact you soon.' , 'result' => null]);

	}
}
