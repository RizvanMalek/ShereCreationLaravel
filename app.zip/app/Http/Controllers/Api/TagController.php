<?php

namespace App\Http\Controllers\Api;

use App\Models\Tag;
use App\Models\Product;
use App\Constants\Status;
use App\Helpers\Transformers\ProductTransformer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\Transformers\TagTransformer;

class TagController extends ApiController
{
    /**
     * @var Helpers\Transformers\TagTransformer
     */
    protected $tagTransformer;

    /**
     * @ Helpers\Transformers\ProductTransformer
     */
    protected $productTransformer;

    function __construct( TagTransformer $tagTransformer, ProductTransformer $productTransformer)
    {
        $this->tagTransformer = $tagTransformer;
        $this->productTransformer = $productTransformer;

        $this->middleware('auth.basic', ['only' => ['store']]);
    }

    /**
     * Display a listing of the resource.
     *@param productId
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $productId = NULL)
    {
        $product = NULL;

        $limit = $request->input('limit') ?: $this->limit;

        if($productId){
            $product = Product::stored()->status(Status::$ACTIVE)->productId($productId)->first();

            if(! $product)
                return $this->respondNotFound('Product does not exists');
        }

        $tags = $product ?  $product->tags()->paginate($limit) : Tag::stored()->status(Status::$ACTIVE)->paginate($limit);

        if(! $tags){
            return $this->respondNotFound('No tags found!');
        }

        return $this->respondWithPagination($tags, [
            'data' => $this->tagTransformer->transformCollection($tags->getCollection())
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $tagId
     * @return \Illuminate\Http\Response
     */
    public function show($tagId)
    {
        $tag = Tag::stored()->status(Status::$ACTIVE)->tagId($tagId)->first();

        if(! $tag)
            return $this->respondNotFound('Tag does not exists');

        return $this->respond([
            'data' => $this->tagTransformer->transform($tag)
        ]);
    }

    /**
     * Function to reterive the products related to specified Tag
     * @param Request $request
     * @param $tagId
     * @return mixed
     */
    public function products(Request $request, $tagId){

        $limit = $request->input('limit') ?: $this->limit;

        $tag = Tag::stored()->status(Status::$ACTIVE)->tagId($tagId)->first();

        if(! $tag)
            return $this->respondNotFound('Tag does not exists');

        // dd($tag->products);
        $products = $tag->products()->paginate($limit);
        // dd($products->toArray());
        if(! $products )
            return $this->respondNotFound('No products found matching with selected tag.');

        return $this->respondWithPagination($products, [
            'tag' => $this->tagTransformer->transform($tag),
            'data' => $this->productTransformer->transformCollection($products->getCollection())
        ]);

    }


}
