<?php

namespace App\Http\Controllers\Api;

use App\Models\Category;
use App\Constants\Status;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\Transformers\ProductTransformer;
use App\Helpers\Transformers\CategoryTransformer;

class CategoryController extends ApiController
{
    /**
     * @var Helpers\Transformers\CategoryTransformer
     */
    protected $categoryTransformer;

    /**
     * @var Helpers\Transformers\ProductTransformer
     */
    protected $productTransformer;

    function __construct( CategoryTransformer $categoryTransformer, ProductTransformer $productTransformer)
    {
        $this->categoryTransformer = $categoryTransformer;
        $this->productTransformer = $productTransformer;

        $this->middleware('auth.basic', ['only' => 'store']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $categories = Category::stored()->status(Status::$ACTIVE)->get();
        // return new CategoryCollection( $categories );

        $limit = $request->input('limit') ?: $this->limit;

        $categories = Category::stored()->status(Status::$ACTIVE)->paginate($limit);

        if(! $categories ){
            return $this->respondNotFound('No categories found!');
        }

        if( $categories->isEmpty() ){
            return $this->respondNotFound('No categories found on this page!');
        }

        return $this->respondWithPagination($categories, [
            //convert LengthAwarePagination object to Collection before treanformation
            'data' => $this->categoryTransformer->transformCollection($categories->getCollection())
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($categoryId)
    {
        // return new CategoryResource($category);

        $category = Category::stored()->status(Status::$ACTIVE)->categoryId($categoryId)->first();

        if(! $category)
            return $this->respondNotFound('Category does not exists');

        return $this->respond([
            'data' => $this->categoryTransformer->transform($category)
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Function to reterive the products related to specified Category
     * @param Request $request
     * @param $categoryId
     * @return mixed
     */
    public function products(Request $request, $categoryId){

        $limit = $request->input('limit') ?: $this->limit;

        $category = Category::stored()->status(Status::$ACTIVE)->categoryId($categoryId)->first();

        if(! $category)
            return $this->respondNotFound('Category does not exists');

        // dd($category->products);
        $products = $category->products()->paginate($limit);
        if(! $products )
        return $this->respondNotFound('No products found matching with selected category.');

        // dd($products->getCollection());
        return $this->respondWithPagination($products, [
            'category' => $this->categoryTransformer->transform($category),
            'data' => $this->productTransformer->transformCollection($products->getCollection())
        ]);

    }
}
