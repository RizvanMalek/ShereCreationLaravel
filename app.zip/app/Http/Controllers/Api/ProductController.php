<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

use App\Models\Product;
use App\Constants\Status;
use App\Helpers\Transformers\ProductTransformer;

class ProductController extends ApiController
{
    /**
     * @var Helpers\Transformers\ProductTransformer
     */
    protected $productTransformer;

    function __construct( ProductTransformer $productTransformer)
    {
        $this->productTransformer = $productTransformer;

        $this->middleware('auth.basic', ['only' => 'store']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $limit = $request->input('limit') ?: $this->limit;

        $products = Product::stored()->status(Status::$ACTIVE)->orderBy('views', 'desc')->paginate($limit);
        // dd($products->items());
        // dd(get_class_methods($products));

        if(! $products ){
            return $this->respondNotFound('No products found!');
        }

        if( $products->isEmpty() ){
            return $this->respondNotFound('No products found on this page!');
        }

        return $this->respondWithPagination($products, [
            //convert LengthAwarePagination object to Collection before treanformation
            'data' => $this->productTransformer->transformCollection($products->getCollection())
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return false; //TODO: remove this route

        if(! $request->input('name') || !$request->input('description')){
            return $this->respondWithValidationError('Parameters failed validation for a product creation');
        }

        // dd('product created');

        return $this->respondCreated([
            'status'    => 'success',
            'message' => 'Product created successfully.'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Model\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($productId)
    {
        $product = Product::stored()->status(Status::$ACTIVE)->productId($productId)->first();

        if(! $product)
            return $this->respondNotFound('Product does not exists');

        return $this->respond([
            'data' => $this->productTransformer->transform($product)
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Model\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Model\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Model\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }

    /**
     * Search products
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $limit = $request->input('limit') ?: $this->limit;

        $query = $request->input('query') ?: '';

        $products = Product::stored()
            ->status(Status::$ACTIVE)
            ->search($query)
            ->orderBy('views', 'desc')
            ->paginate($limit);
        // dd($products->items());
        // dd(get_class_methods($products));

        if(! $products ){
            return $this->respondNotFound('No products found!');
        }

        if( $products->isEmpty() ){
            return $this->respondNotFound('No products found on this page!');
        }

        return $this->respondWithPagination($products, [
            //convert LengthAwarePagination object to Collection before treanformation
            'data' => $this->productTransformer->transformCollection($products->getCollection())
        ]);
    }
}
