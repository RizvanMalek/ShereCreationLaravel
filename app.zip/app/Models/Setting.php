<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Constants\Status;
use App\Helpers\UniqueNumberHelper;

class Setting extends Model
{
	use SoftDeletes;

	protected $table = 'settings';
	protected $primaryKey = 'autoId';
	protected $hidden = ['autoId'];
	protected $dates = ['deletedAt'];
	protected $appends = ['photo'];

	const CREATED_AT = 'createdAt';
	const UPDATED_AT = 'updatedAt';
	const DELETED_AT = 'deletedAt';

	public static function boot() {
		parent::boot();

		Setting::creating(function($setting) {
			$setting->settingId = uuid();
			$setting->settingNo = UniqueNumberHelper::get_no('Setting', 'STG');

			if(!$setting->status) {
				$setting->status = Status::$ACTIVE;
			}
		});
	}

	public static function get($settingId) {
		return Setting::where('settingId', $settingId)->first();
	}

	public static function scopeStored($query) {
		return $query->whereNull('deletedAt');
	}

	public static function scopeSettingId($query, $settingId) {
		return $query->where('settingId', $settingId);
	}

	public static function scopeSettingNo($query, $setting_no)
	{
		return $query->where('settingNo', $setting_no);
	}

	public static function scopeName($query, $name)
	{
		return $query->where('name', $name);
	}

	public static function scopeValue($query, $value)
	{
		return $query->where('value', $value);
	}

	public static function scopeType($query, $type) {
		return $query->where('type', $type);
	}

	public static function scopeStatus($query , $status) {
		return $query->where('status', $status);
	}

	public static function get_settings()
	{
		$settings = [];
		$settings_row = self::stored()->get();

		foreach ($settings_row as $key => $setting) {
			$settings[$setting['name']] = $setting['value'];
		}

		return $settings;
	}
}