<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Constants\Status;
use App\Helpers\UniqueNumberHelper;
use App\Helpers\AttachmentHelper;
use App\Constants\CommonConstants;

class Page extends Model
{
	use SoftDeletes;

	const CREATED_AT = 'createdAt';
	const UPDATED_AT = 'updatedAt';
	const DELETED_AT = 'deletedAt';

	protected $table = 'pages';
	protected $primaryKey = 'autoId';
	protected $hidden = ['autoId'];
	protected $dates = ['deletedAt'];
	protected $appends = ['photo'];

	public static function boot() {
		parent::boot();

		Page::creating(function($page) {
			$page->pageId = uuid();
			$page->pageNo = UniqueNumberHelper::get_no( 'Page', 'PAG' );

			if(!$page->status) {
				$page->status = Status::$ACTIVE;
			}
		});
	}

    public static function get($pageId) {
        return Page::where('pageId', $pageId)->first();
    }

    public static function scopeStored($query) {
        return $query->whereNull('deletedAt');
    }

    public static function scopePageId($query, $pageId) {
        return $query->where('pageId', $pageId);
    }

    public static function scopePageNo($query, $page_no)
    {
        return $query->where('pageNo', $page_no);
    }

    public static function scopeStatus($query , $status) {
        return $query->where('status', $status);
    }

    public static function scopeSearch($query, $term) {
        $searchTerm = '%' . $term . '%';

        return $query->where(function($q) use ($searchTerm) {
            $q->where('title', 'like', $searchTerm)->orWhere('subtitle', 'like', $searchTerm)->orWhere('description', 'like', $searchTerm);
        });
    }

    public function getPhotoAttribute() {
        if($this->photoId) {
            return AttachmentHelper::renderUrl($this->photoId);
        }
        return asset('assets/panel/app/assets/images/default-placeholder.png');
    }
}