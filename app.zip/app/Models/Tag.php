<?php

namespace App\Models;

use App\Models\Product;

use App\Constants\Status;
use App\Helpers\AttachmentHelper;
use App\Helpers\UniqueNumberHelper;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
	protected $table = 'tags';
	protected $primaryKey = 'autoId';
	protected $hidden = ['autoId'];
	protected $casts = ['tagId' => 'string'];

	public static function boot()
	{
		parent::boot();

		Tag::creating(function($tag)
		{
			$tag->tagId = uuid();
			$tag->tagNo = UniqueNumberHelper::get_no('Tag', 'TAG');
			$tag->status = $tag->status ? $tag->status : Status::$ACTIVE;
		});
	}

	public function products()
    {
		return $this->belongsToMany(Product::class, 'product_tag', 'tagAutoId', 'productAutoId');
    }

	public static function get($tagId)
	{
		return Tag::where('tagId' , $tagId)->first();
	}

	public static function scopeStored($query)
	{
		// return $query->whereNull('deleted_at');
		return $query;
	}

	public static function scopeName($query , $name)
	{
		return $query->where('name', $name);
	}

	public static function scopeTagNo($query , $tagNo)
	{
		return $query->where('tagNo', $tagNo);
	}

	public static function scopeTagId($query , $tagId)
	{
		return $query->where('tagId', $tagId);
	}

	public static function scopeSlug($query , $slug)
	{
		return $query->where('slug', $slug);
	}

	public static function scopeStatus($query , $status)
	{
		return $query->where('status', $status);
	}

	public static function scopeSearch($query, $term)
	{
		$search_term = '%' . $term . '%';

		return $query->where(function($q) use ($search_term)
		{
			$q->where('name', 'like', $search_term)->orWhere('tagNo', 'like', $search_term);
		});
	}

	public function getPhotoAttribute()
	{
		if ($this->photoId) {
			return AttachmentHelper::renderUrl($this->photoId);
		}
		return asset('assets/panel/app/assets/images/default-placeholder.png');
	}
}
