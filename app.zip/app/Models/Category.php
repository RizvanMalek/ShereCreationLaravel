<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Models\Product;
use App\Models\Subcategory;

use App\Constants\Status;
use App\Helpers\AttachmentHelper;
use App\Helpers\UniqueNumberHelper;

class Category extends Model
{
	use SoftDeletes;
	protected $table = 'categories';
	protected $primaryKey = 'autoId';
	protected $hidden = ['autoId'];
    protected $guarded = ['autoId'];
	protected $dates = ['deleted_at'];
	protected $casts = ['categoryId' => 'string'];

	public static function boot()
	{
		parent::boot();

		Category::creating(function($category)
		{
			$category->categoryId = uuid();
			$category->categoryNo = UniqueNumberHelper::get_no('Category', 'CAT');
			$category->status = $category->status ? $category->status : Status::$ACTIVE;
		});
	}

	public function Subcategory()
	{
		return $this->hasMany(Subcategory::class, 'categoryId', 'categoryId');
	}

	public function Products()
    {
        return $this->hasMany(Product::class, 'categoryId', 'categoryId');
    }

	public static function get($categoryId)
	{
		return Category::where('categoryId' , $categoryId)->first();
	}

	public static function scopeStored($query)
	{
		return $query->whereNull('deleted_at');
	}

	public static function scopeName($query , $name)
	{
		return $query->where('name', $name);
	}

	public static function scopeCategoryNo($query , $categoryNo)
	{
		return $query->where('categoryNo', $categoryNo);
	}

	public static function scopeCategoryId($query , $categoryId)
	{
		return $query->where('categoryId', $categoryId);
	}

	public static function scopeSlug($query , $slug)
	{
		return $query->where('slug', $slug);
	}

	public static function scopeStatus($query , $status)
	{
		return $query->where('status', $status);
	}

	public static function scopeSearch($query, $term)
	{
		$search_term = '%' . $term . '%';

		return $query->where(function($q) use ($search_term)
		{
			$q->where('name', 'like', $search_term)->orWhere('categoryNo', 'like', $search_term);
		});
	}

	public function getPhotoAttribute()
	{
		if ($this->photoId) {
			return AttachmentHelper::renderUrl($this->photoId);
		}
		return asset('assets/panel/app/assets/images/default-placeholder.png');
	}
}
