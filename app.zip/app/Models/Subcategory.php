<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Models\Product;
use App\Models\Category;

use App\Constants\Status;
use App\Helpers\AttachmentHelper;
use App\Helpers\UniqueNumberHelper;

class Subcategory extends Model
{
	use SoftDeletes;
	protected $table = 'subcategories';
	protected $primaryKey = 'autoId';
	protected $hidden = ['autoId'];
	protected $dates = ['deleted_at'];
	protected $casts = ['subcategoryId' => 'string', 'categoryId' => 'string'];

	public static function boot()
	{
		parent::boot();

		Subcategory::creating(function($subcategory)
		{
			$subcategory->subcategoryId = uuid();
			$subcategory->subcategoryNo = UniqueNumberHelper::get_no('Subcategory', 'SCT');
			$subcategory->status = $subcategory->status ? $subcategory->status : Status::$ACTIVE;
		});
	}

	public function Category()
	{
		return $this->belongsTo(Category::class, 'categoryId', 'categoryId');
	}

	public function Products()
    {
        return $this->hasMany(Product::class, 'subcategoryId', 'subcategoryId');
    }

	public static function get($subcategoryId)
	{
		return Subcategory::where('subcategoryId' , $subcategoryId)->first();
	}

	public static function scopeStored($query)
	{
		return $query->whereNull('deleted_at');
	}

	public static function scopeName($query , $name)
	{
		return $query->where('name', $name);
	}

	public static function scopeSubcategoryNo($query , $subcategoryNo)
	{
		return $query->where('subcategoryNo', $subcategoryNo);
	}

	public static function scopeSubcategoryId($query , $subcategoryId)
	{
		return $query->where('subcategoryId', $subcategoryId);
	}

	public static function scopeCategoryId($query , $categoryId)
	{
		return $query->where('categoryId', $categoryId);
	}

	public static function scopeSlug($query , $slug)
	{
		return $query->where('slug', $slug);
	}

	public static function scopeStatus($query , $status)
	{
		return $query->where('status', $status);
	}

	public static function scopeSearch($query, $term)
	{
		$search_term = '%' . $term . '%';

		return $query->where(function($q) use ($search_term)
		{
			$q->where('name', 'like', $search_term)->orWhere('subcategoryNo', 'like', $search_term);
		});
	}

	public function getPhotoAttribute()
	{
		if ($this->photoId) {
			return AttachmentHelper::renderUrl($this->photoId);
		}
		return asset('assets/panel/app/assets/images/default-placeholder.png');
	}
}
