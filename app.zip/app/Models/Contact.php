<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Constants\Status;
use App\Helpers\UniqueNumberHelper;

class Contact extends Model
{
    use SoftDeletes;

    const CREATED_AT = 'createdAt';
    const UPDATED_AT = 'updatedAt';
    const DELETED_AT = 'deletedAt';

    protected $table = 'contacts';
    protected $primaryKey = 'autoId';
    protected $hidden = ['autoId'];
    protected $dates = ['deletedAt'];

    public static function boot() {
    	parent::boot();

    	Contact::creating(function($contact) {
    		$contact->contactId = uuid();
    		$contact->contactNo = UniqueNumberHelper::get_no( 'Contact', 'CNT' );

			if(!$contact->status) {
				$contact->status = Status::$ACTIVE;
			}
    	});
    }

    public static function get($contactId) {
        return Contact::where('contactId', $contactId)->first();
    }

    public static function scopeStored($query) {
        return $query->whereNull('deletedAt');
    }

    public static function scopeContactId($query, $contactId) {
        return $query->where('contactId', $contactId);
    }

    public static function scopeContactNo($query, $contactNo)
    {
        return $query->where('contactNo', $contactNo);
    }

    public static function scopeStatus($query , $status) {
        return $query->where('status', $status);
    }

    public static function scopeSearch($query, $term) {
        $searchTerm = '%' . $term . '%';

        return $query->where(function($q) use ($searchTerm) {
            $q->where('firstName', 'like', $searchTerm)->orWhere('lastName', 'like', $searchTerm)->orWhere('email', 'like', $searchTerm)->orWhere('message', 'like', $searchTerm);
        });
    }
}