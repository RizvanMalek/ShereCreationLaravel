<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Constants\Status;
use App\Helpers\UniqueNumberHelper;

class Gallery extends Model
{
    use SoftDeletes;

    const CREATED_AT = 'createdAt';
    const UPDATED_AT = 'updatedAt';
    const DELETED_AT = 'deletedAt';

    protected $table = 'gallery';
    protected $primaryKey = 'autoId';
    protected $hidden = ['autoId'];
    protected $dates = ['deletedAt'];
    protected $appends = ['photo'];

    public static function boot() {
    	parent::boot();

    	Gallery::creating(function($gallery) {
    		$gallery->galleryId = uuid();
    		$gallery->galleryNo = UniqueNumberHelper::get_no( 'Gallery', 'GLR' );

			if(!$gallery->status) {
				$gallery->status = Status::$ACTIVE;
			}
    	});
    }

    public static function get($galleryId) {
        return Gallery::where('galleryId', $galleryId)->first();
    }

    public static function scopeStored($query) {
        return $query->whereNull('deletedAt');
    }

    public static function scopeGalleryId($query, $galleryId) {
        return $query->where('galleryId', $galleryId);
    }

    public static function scopeGalleryNo($query, $gallery_no)
    {
        return $query->where('galleryNo', $gallery_no);
    }

    public static function scopeType($query, $type) {
        return $query->where('type', $type);
    }

    public static function scopeGalleryDate($query, $date) {
        return $query->where('date', '>=', $date);
    }

    public static function scopeStatus($query , $status) {
        return $query->where('status', $status);
    }

    public static function scopeSearch($query, $term) {
        $searchTerm = '%' . $term . '%';

        return $query->where(function($q) use ($searchTerm) {
            $q->where('title', 'like', $searchTerm)->orWhere('date', 'like', $searchTerm);
        });
    }

    public function getPhotoAttribute() {
        $photos = json_decode($this->photos);
        if (is_array($photos) && count($photos)) {
            return $photos[0]->renderUrl;
        }
        return asset('/assets/panel/app/assets/images/default-placeholder.png');
    }
}
