<?php

namespace App\Models;

use App\Models\Tag;
use App\Constants\Status;
use App\Helpers\UniqueNumberHelper;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use SoftDeletes;
    protected $table = 'products';
    protected $primaryKey = 'autoId';
    protected $hidden = ['autoId'];
    protected $guarded = ['autoId'];
    protected $dates = ['deleted_at'];
    protected $casts = ['productId' => 'string', 'categoryId' => 'string'];

    public static function boot()
    {
        parent::boot();

        self::creating(function ($product) {
            $product->productId = uuid();
            $product->productNo = UniqueNumberHelper::get_no('Product', 'PRD');
            $product->status = $product->status ? $product->status : Status::$ACTIVE;
        });
    }

    public function Category()
    {
        return $this->hasOne(Category::class, 'categoryId', 'categoryId');
    }

    public function Subcategory()
    {
        return $this->hasOne(Subcategory::class, 'subcategoryId', 'subcategoryId');
    }

    public function tags()
    {
        return $this->belongsToMany(Tag::class, 'product_tag', 'productAutoId', 'tagAutoId');
    }

    public static function get($productId)
    {
        return self::where('productId', $productId)->first();
    }

    public static function scopeStored($query)
    {
        return $query->whereNull('deleted_at');
    }

    public static function scopeName($query, $name)
    {
        return $query->where('name', $name);
    }

    public static function scopeProductNo($query, $productNo)
    {
        return $query->where('productNo', $productNo);
    }

    public static function scopeProductId($query, $productId)
    {
        return $query->where('productId', $productId);
    }

    public static function scopeSlug($query, $slug)
    {
        return $query->where('slug', $slug);
    }

    public static function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    public static function scopeCategoryId($query, $categoryId)
    {
        return $query->where('categoryId', $categoryId);
    }

    public static function scopeSubcategoryId($query, $subcategoryId)
    {
        return $query->where('subcategoryId', $subcategoryId);
    }

    public static function scopeSearch($query, $term)
    {
        $search_term = '%'.$term.'%';

        return $query->where(function ($q) use ($search_term) {
            $q->where('name', 'like', $search_term)->orWhere('productNo', 'like', $search_term);
        });
    }

    public function getPhotoAttribute()
    {
        $photos = json_decode($this->photos);
        if (is_array($photos) && count($photos)) {
            return $photos[0]->renderUrl;
        }
        return asset('/assets/panel/app/assets/images/default-placeholder.png');
    }
}
