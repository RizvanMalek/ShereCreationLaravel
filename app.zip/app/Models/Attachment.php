<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Constants\Status;
use App\Helpers\AttachmentHelper;

class Attachment extends Model
{
    use SoftDeletes;

    const CREATED_AT = 'createdAt';
    const UPDATED_AT = 'updatedAt';
    const DELETED_AT = 'deletedAt';

    protected $table = 'attachments';
    protected $primaryKey = 'autoId';
    protected $hidden = ['autoId'];
    protected $dates = ['deletedAt'];
    protected $appends = ['renderUrl', 'downloadUrl'];

    public static function boot() {
    	parent::boot();

    	Attachment::creating(function($attachment) {
    		$attachment->attachmentId = uuid();
    		$attachment->status = Status::$ACTIVE;
    	});
    }

    public static function scopeStored($query)
    {
        return $query->whereNull('deletedAt');
    }

    public static function getAll() {
    	return Attachment::orderBy('autoId', 'desc')->get();
    }

    public static function get($attachmentId) {
    	return Attachment::where('attachmentId', $attachmentId)->first();
    }

    public function getRenderUrlAttribute() {
    	return AttachmentHelper::renderUrl($this->attachmentId);
    }

    public function getDownloadUrlAttribute() {
    	return AttachmentHelper::downloadUrl($this->attachmentId);
    }
}
