<?php

namespace App\View\Components\Front;

use App\Models\Product;
use App\Models\Category;
use App\Constants\Status;
use Illuminate\View\Component;
use Illuminate\Support\Facades\DB;

class Sidebar extends Component
{

    private $categories;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->categories = Category::stored()->with('Subcategory')->withCount('products')->status(Status::$ACTIVE)->get();
        // dd($this->categories);
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.front.sidebar', ['categories' => $this->categories]);
    }
}
