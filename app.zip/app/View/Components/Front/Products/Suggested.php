<?php

namespace App\View\Components\Front\Products;

use App\Models\Product;
use App\Constants\Status;
use Illuminate\View\Component;

class Suggested extends Component
{

    public $categoryId;
    public $productId;

    public $suggested_products;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($categoryId, $productId)
    {
        $this->productId = $productId;

        $this->suggested_products = Product::stored()->with('Category')->with('Subcategory')->status(Status::$ACTIVE)
            ->categoryId($categoryId)
            ->where('productId', '!=', $productId)
            ->orderBy('views', 'DESC')
            ->limit(3)->get();

    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.front.products.suggested', ['suggested_products' => $this->suggested_products]);
    }
}
