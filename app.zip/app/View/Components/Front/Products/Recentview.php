<?php

namespace App\View\Components\Front\Products;

use App\Models\Product;
use App\Constants\Status;
use Illuminate\View\Component;
use Illuminate\Support\Facades\Session;

class Recentview extends Component
{
    private $recent_products;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        $session_products = array_unique( Session::get('products.recent_view') );

        $session_products = array_slice($session_products, -4, 3, true);

        Session::put('products.recent_view', $session_products);

        $this->recent_products = Product::stored()->status(Status::$ACTIVE)->whereIn('autoId',$session_products)->limit(3)->get();
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.front.products.recentview', ['recent_products' => $this->recent_products]);
    }
}
