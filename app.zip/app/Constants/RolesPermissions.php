<?php

namespace App\Constants;

use Illuminate\Support\Facades\Facade;

class RolesPermissionsFacade extends Facade {
	public static function getFacadeAccessor() {
		return 'RolesPermissions';
	}
}

class RolesPermissions {

	public static $ROLES = [
		'SUPER_ADMIN' 	=> 'Super Admin',
		'ADMIN'			=>'Admin',
		'EDITOR'		=>'Editor',
		'GUEST'			=>'Guest'
	];

	public static $PERMISSIONS = [
		'admin' => [
			'admin_create' => 'ADMIN CREATE',
			'admin_update' => 'ADMIN UPDATE',
			'admin_delete' => 'ADMIN DELETE',
			'admin_view'  => 'ADMIN VIEW',
		],
		'user' => [
			'user_create' => 'USER CREATE',
			'user_update' => 'USER UPDATE',
			'user_delete' => 'USER DELETE',
			'user_view'  => 'USER VIEW',
		],
		'role' => [
			'role_create' => 'ROLE CREATE',
			'role_update' => 'ROLE UPDATE',
			'role_delete' => 'ROLE DELETE',
			'role_view' => 'ROLE VIEW',
		],
		'news' => [
			'news_create' => 'NEWS CREATE',
			'news_update' => 'NEWS UPDATE',
			'news_delete' => 'NEWS DELETE',
			'news_view' => 'NEWS VIEW',
		],
		'faculties' => [
			'faculty_create' => 'FACULTY CREATE',
			'faculty_update' => 'FACULTY UPDATE',
			'faculty_delete' => 'FACULTY DELETE',
			'faculty_view' => 'FACULTY VIEW',
		],
		'studentclubs' => [
			'studentclub_create' => 'STUDENT CLUB CREATE',
			'studentclub_update' => 'STUDENT CLUB UPDATE',
			'studentclub_delete' => 'STUDENT CLUB DELETE',
			'studentclub_view' => 'STUDENT CLUB VIEW',
		],
		'infrastructure' => [
			'infrastructure_create' => 'INFRASTRUCTURE CREATE',
			'infrastructure_update' => 'INFRASTRUCTURE UPDATE',
			'infrastructure_delete' => 'INFRASTRUCTURE DELETE',
			'infrastructure_view' => 'INFRASTRUCTURE VIEW',
		],
		'testimonials' => [
			'testimonial_create' => 'TESTIMONIAL CREATE',
			'testimonial_update' => 'TESTIMONIAL UPDATE',
			'testimonial_delete' => 'TESTIMONIAL DELETE',
			'testimonial_view' => 'TESTIMONIAL VIEW',
		],
		'event' => [
			'event_create' => 'EVENT CREATE',
			'event_update' => 'EVENT UPDATE',
			'event_delete' => 'EVENT DELETE',
			'event_view' => 'EVENT VIEW',
		],
		'page' => [
			'page_create' => 'PAGE CREATE',
			'page_update' => 'PAGE UPDATE',
			'page_delete' => 'PAGE DELETE',
			'page_view' => 'PAGE VIEW',
		],
		'contacts' => [
			'contact_delete' => 'CONTACT DELETE',
			'contact_view' => 'CONTACT VIEW',
		],
		'admissionInquiry' => [
			'admissionInquiry_delete' => 'ADMISSION INQUIRY DELETE',
			'admissionInquiry_view' => 'ADMISSION INQUIRY VIEW',
		],
		'settings' => [
			'settings_update' => 'SETTINGS UPDATE/ADD',
			'settings_view' => 'SETTINGS VIEW',
		],
	];
}
