<?php

namespace App\ViewComposers;

use App\Models\Tag;
use App\Constants\Status;
use Illuminate\View\View;

class HeaderComposer
{
    /**
     * The user repository implementation.
     *
     * @var UserRepository
     */

    protected $menu_tags;

    /**
     * Create a new profile composer.
     *
     * @param  UserRepository  $latest_news
     * @return void
     */
    public function __construct()
    {
        // Dependencies automatically resolved by service container...

        $tags = Tag::stored()->status(Status::$ACTIVE)->get();

        foreach ($tags as $key => $tag) {
            $this->menu_tags[$tag->group][] = $tag;
        }
    }

    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('menu_tags', $this->menu_tags);
    }
}