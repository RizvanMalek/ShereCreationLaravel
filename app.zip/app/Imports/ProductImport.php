<?php

namespace App\Imports;

use App\Models\Product;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ProductImport implements ToModel, WithHeadingRow
{

    public function headingRow(): int
    {
        return 2;
    }

    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        if (!isset($row[0])) {
            return null;
        }

        $category = Category::stored()->slug($row[1])->first();
        $subcategory = Subcategory::stored()->slug($row[2])->first();

        return new Product([
            'SKU'           => $row[0],
            'categoryId'    => $category->categoryId ?? '',
            'subcategoryId' => $subcategory->subcategoryId ?? '',
            'name'          => $row[3],
            'slug'          => Str::slug(strtolower($row[3]), '_'),
            'dp'            => $row[4],
            'margin'        => $row[5],
            'mrp'           => $row[6]
        ]);
    }
}
