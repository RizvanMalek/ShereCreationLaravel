<?php

namespace App\Helpers\Transformers;

class ProductTransformer extends Transformer{

    public function transform($product)
    {
        return [
            'id'            => $product->autoId,
            'product_id'    => $product->productId,
            'product_no'    => $product->productNo,
            'name'          => $product->name,
            'description'   => strip_tags( $product->description),
            'price'         => $product->dp,
            'mrp'           => $product->mrp,
            'stock'         => (boolean) $product->availability,
            'image'         => $product->photo
        ];
    }


}