<?php

namespace App\Helpers\Transformers;

class TagTransformer extends Transformer{

    public function transform($tag)
    {
        return [
            'tag_id'    => $tag->tagId,
            'tag_no'    => $tag->tagNo,
            'name'      => $tag->name,
            'slug'      => $tag->slug,
            'group'     => $tag->group
        ];
    }

}