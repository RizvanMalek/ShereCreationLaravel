<?php

namespace App\Helpers\Transformers;

class CategoryTransformer extends Transformer{

    public function transform($category)
    {
        return [
            'id'            => $category->autoId,
            'category_id'    => $category->categoryId,
            'category_no'    => $category->categoryNo,
            'name'          => $category->name,
            'description'   => strip_tags( $category->description),
            'image'         => $category->photo
        ];
    }


}