<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class ComposerServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        \View::composer(
            [
                'layouts.front.includes.header',
                'layouts.front.includes.footer',
            ],
            'App\ViewComposers\SettingsComposer'
        );

        \View::composer(
            [
                'layouts.front.includes.footer'
            ],
            'App\ViewComposers\FooterComposer'
        );

        \View::composer(
            [
                'layouts.front.includes.header'
            ],
            'App\ViewComposers\HeaderComposer'
        );
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
